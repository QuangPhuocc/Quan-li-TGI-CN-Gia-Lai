import React, { useState, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { InsuranceOrder, InsuranceType } from '../types';
import { Plus, Search, Filter, Download, Upload, Edit, Trash, X } from 'lucide-react';
import { format } from 'date-fns';

export default function Orders() {
  const { user } = useAuth();
  const { orders, users, addOrder, updateOrder } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [filterPayment, setFilterPayment] = useState('ALL');
  const [filterMonth, setFilterMonth] = useState('ALL');
  const [filterProvider, setFilterProvider] = useState('ALL');
  const [filterInsurance, setFilterInsurance] = useState<InsuranceType | 'ALL'>('ALL');
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState<InsuranceOrder | null>(null);

  const filteredOrders = useMemo(() => {
    let result = orders;

    if (filterInsurance !== 'ALL') {
      result = result.filter(o => o.insurance_type === filterInsurance);
    }

    if (filterMonth !== 'ALL') {
      result = result.filter(o => {
        const d = new Date(o.issue_date);
        const monthYear = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        return monthYear === filterMonth;
      });
    }

    if (filterProvider !== 'ALL') {
      result = result.filter(o => o.provider === filterProvider);
    }

    // Phân quyền dữ liệu
    if (user?.role === 'STAFF') {
      const myAgencies = users.filter(u => u.parent_id === user.id).map(u => u.id);
      result = result.filter(o => o.staff_id === user.id || (o.agency_id && myAgencies.includes(o.agency_id)));
    } else if (user?.role === 'AGENCY') {
      result = result.filter(o => o.agency_id === user.id);
    }

    if (searchTerm) {
      result = result.filter(o => o.vehicle_owner.toLowerCase().includes(searchTerm.toLowerCase()) || 
                                  o.license_plate.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                  o.serial_number.toLowerCase().includes(searchTerm.toLowerCase()));
    }
    
    if (filterStatus !== 'ALL') {
      if (filterStatus === 'NEEDS_PROCESSING') {
        result = result.filter(o => !o.agency_id || !o.customer_phone || !o.cod_amount);
      } else {
        result = result.filter(o => o.status === filterStatus);
      }
    }

    if (filterPayment !== 'ALL') {
      result = result.filter(o => o.payment_status === filterPayment);
    }

    return result;
  }, [orders, user, users, searchTerm, filterStatus, filterPayment, filterInsurance, filterMonth, filterProvider]);

  const uniqueProviders = useMemo(() => {
    const providers = new Set(orders.map(o => o.provider).filter(Boolean));
    return Array.from(providers).sort();
  }, [orders]);

  const uniqueMonths = useMemo(() => {
    const months = new Set(orders.map(o => {
      const d = new Date(o.issue_date);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    }));
    return Array.from(months).sort().reverse();
  }, [orders]);

  const INSURANCE_TABS = [
    { id: 'ALL', label: 'Tất cả' },
    { id: 'TNDS_OTO', label: 'TNDS Ô tô' },
    { id: 'VCX_OTO', label: 'VCX Ô tô' },
    { id: 'TNDS_XEMAY', label: 'TNDS Xe máy' },
    { id: 'Y_TE', label: 'BH Y tế' },
    { id: 'ETC', label: 'Thẻ ETC' },
    { id: 'KHAC', label: 'Khác' },
  ];

  const handleOpenModal = (order?: InsuranceOrder) => {
    if (order) setEditingOrder(order);
    else setEditingOrder(null);
    setIsModalOpen(true);
  };

  const handleSave = (formData: any) => {
    if (editingOrder) {
      updateOrder(editingOrder.id, formData);
    } else {
      addOrder({
        ...formData,
        id: `ORD-${Date.now()}`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
    }
    setIsModalOpen(false);
  };

  const handleStatusChange = (id: string, status: 'ACTIVE' | 'CANCELLED') => {
    if (window.confirm(`Bạn có chắc muốn ${status === 'CANCELLED' ? 'hủy' : 'khôi phục'} đơn này?`)) {
      updateOrder(id, { status });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-semibold text-slate-800">Quản lý Đơn Bảo Hiểm</h1>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium hover:bg-slate-50">
            <Upload className="w-4 h-4" /> Import
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium hover:bg-slate-50">
            <Download className="w-4 h-4" /> Export
          </button>
          <button 
            onClick={() => handleOpenModal()}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 shadow-sm"
          >
            <Plus className="w-4 h-4" /> Thêm đơn
          </button>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-col gap-4">
        <div className="flex overflow-x-auto pb-2 -mb-2 gap-2 hide-scrollbar">
          {INSURANCE_TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilterInsurance(tab.id as any)}
              className={`whitespace-nowrap px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filterInsurance === tab.id 
                  ? 'bg-blue-100 text-blue-700' 
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="w-5 h-5 absolute left-3 top-2.5 text-slate-400" />
            <input 
              type="text" 
              placeholder="Tìm kiếm chủ xe, biển số, seri..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm"
            />
          </div>
          <div className="flex flex-wrap gap-4">
            <select 
              value={filterProvider}
              onChange={(e) => setFilterProvider(e.target.value)}
              className="border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="ALL">Tất cả hãng</option>
              {uniqueProviders.map(p => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
            <select 
              value={filterMonth}
              onChange={(e) => setFilterMonth(e.target.value)}
              className="border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="ALL">Tất cả tháng</option>
              {uniqueMonths.map(m => (
                <option key={m} value={m}>Tháng {m.split('-')[1]}/{m.split('-')[0]}</option>
              ))}
            </select>
            <select 
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="ALL">Tất cả trạng thái</option>
              <option value="NEEDS_PROCESSING">Cần xử lý</option>
              <option value="ACTIVE">Đang hiệu lực</option>
              <option value="CANCELLED">Đã hủy</option>
            </select>
            <select 
              value={filterPayment}
              onChange={(e) => setFilterPayment(e.target.value)}
              className="border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="ALL">Tất cả thanh toán</option>
              <option value="UNPAID">Chưa thanh toán</option>
              <option value="PARTIAL">Thanh toán 1 phần</option>
              <option value="PAID">Đã thanh toán</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-sky-100 border-b border-slate-300 text-sm font-semibold text-slate-700 whitespace-nowrap">
                <th className="px-3 py-3 text-center border-r border-slate-300">STT</th>
                <th className="px-3 py-3 border-r border-slate-300">GCN</th>
                <th className="px-3 py-3 border-r border-slate-300">TÊN KHÁCH HÀNG</th>
                <th className="px-3 py-3 border-r border-slate-300">BIỂN SỐ</th>
                <th className="px-3 py-3 border-r border-slate-300">NGÀY CẤP</th>
                <th className="px-3 py-3 border-r border-slate-300">NGÀY HIỆU LỰC</th>
                <th className="px-3 py-3 border-r border-slate-300 text-right">PHÍ TNDS</th>
                <th className="px-3 py-3 border-r border-slate-300 text-right">LP NNTX</th>
                <th className="px-3 py-3 border-r border-slate-300 text-right">TỔNG PHÍ</th>
                <th className="px-3 py-3 border-r border-slate-300 text-center">TRẠNG THÁI</th>
                <th className="px-3 py-3 border-r border-slate-300">NGƯỜI CẤP</th>
                <th className="px-3 py-3 border-r border-slate-300">ĐẠI LÝ</th>
                <th className="px-3 py-3 border-r border-slate-300">SDT</th>
                <th className="px-3 py-3 border-r border-slate-300 text-right">COD</th>
                <th className="px-3 py-3 border-r border-slate-300 text-right">VẬN CHUYỂN</th>
                <th className="px-3 py-3 border-r border-slate-300">GHI CHÚ</th>
                <th className="px-3 py-3 border-r border-slate-300">HÃNG</th>
                <th className="px-3 py-3 text-center border-l-2 border-slate-300 sticky right-0 bg-sky-100 z-10 shadow-[-4px_0_6px_-2px_rgba(0,0,0,0.1)]">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-sm">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={18} className="px-6 py-8 text-center text-slate-500">
                    Không tìm thấy đơn bảo hiểm nào
                  </td>
                </tr>
              ) : filteredOrders.map((order, index) => {
                const staffName = users.find(u => u.id === order.staff_id)?.fullname || '';
                const agencyName = users.find(u => u.id === order.agency_id)?.fullname || '';
                return (
                  <tr key={order.id} className="hover:bg-slate-50 transition-colors bg-white">
                    <td className="px-3 py-2 text-center border-r border-slate-200">{index + 1}</td>
                    <td className="px-3 py-2 border-r border-slate-200 font-medium text-slate-900 whitespace-nowrap">{order.serial_number || order.id}</td>
                    <td className="px-3 py-2 border-r border-slate-200">{order.vehicle_owner}</td>
                    <td className="px-3 py-2 border-r border-slate-200 whitespace-nowrap">{order.license_plate}</td>
                    <td className="px-3 py-2 border-r border-slate-200 whitespace-nowrap">{format(new Date(order.issue_date), 'dd/MM/yyyy')}</td>
                    <td className="px-3 py-2 border-r border-slate-200 whitespace-nowrap">{format(new Date(order.effective_date), 'dd/MM/yyyy')}</td>
                    <td className="px-3 py-2 border-r border-slate-200 text-right whitespace-nowrap">{new Intl.NumberFormat('vi-VN').format(order.tnds_fee)}</td>
                    <td className="px-3 py-2 border-r border-slate-200 text-right whitespace-nowrap">{new Intl.NumberFormat('vi-VN').format(order.nn_fee)}</td>
                    <td className="px-3 py-2 border-r border-slate-200 text-right whitespace-nowrap font-medium">{new Intl.NumberFormat('vi-VN').format(order.total_fee)}</td>
                    <td className="px-3 py-2 border-r border-slate-200 text-center">
                      <div className="flex flex-col gap-1 items-center">
                        <StatusBadge status={order.status} notes={order.notes} order={order} />
                        <PaymentBadge status={order.payment_status} />
                      </div>
                    </td>
                    <td className="px-3 py-2 border-r border-slate-200 whitespace-nowrap">{staffName}</td>
                    <td className="px-3 py-2 border-r border-slate-200 whitespace-nowrap">{agencyName}</td>
                    <td className="px-3 py-2 border-r border-slate-200 whitespace-nowrap">{order.customer_phone}</td>
                    <td className="px-3 py-2 border-r border-slate-200 text-right whitespace-nowrap">{new Intl.NumberFormat('vi-VN').format(order.cod_amount)}</td>
                    <td className="px-3 py-2 border-r border-slate-200 text-right whitespace-nowrap">{new Intl.NumberFormat('vi-VN').format(order.shipping_fee)}</td>
                    <td className="px-3 py-2 border-r border-slate-200 max-w-xs truncate" title={order.notes}>{order.notes}</td>
                    <td className="px-3 py-2 border-r border-slate-200 whitespace-nowrap">{order.provider}</td>
                    <td className="px-3 py-2 text-center sticky right-0 bg-white border-l-2 border-slate-200 shadow-[-4px_0_6px_-2px_rgba(0,0,0,0.05)]">
                      <div className="flex items-center justify-center gap-2">
                        <button 
                          onClick={() => handleOpenModal(order)}
                          className="p-1 text-slate-400 hover:text-blue-600 transition-colors" title="Sửa"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        {order.status === 'ACTIVE' ? (
                          <button 
                            onClick={() => handleStatusChange(order.id, 'CANCELLED')}
                            className="p-1 text-slate-400 hover:text-red-600 transition-colors" title="Hủy đơn"
                          >
                            <Trash className="w-4 h-4" />
                          </button>
                        ) : (
                          <button 
                            onClick={() => handleStatusChange(order.id, 'ACTIVE')}
                            className="p-1 text-slate-400 hover:text-emerald-600 transition-colors" title="Khôi phục"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <OrderFormModal 
          order={editingOrder} 
          onClose={() => setIsModalOpen(false)} 
          onSave={handleSave} 
          users={users}
          currentUser={user!}
        />
      )}
    </div>
  );
}

function PaymentBadge({ status }: { status: string }) {
  if (status === 'PAID') return <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-emerald-100 text-emerald-700">Đã TT</span>;
  if (status === 'PARTIAL') return <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-amber-100 text-amber-700">TT 1 phần</span>;
  return <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-700">Chưa TT</span>;
}

function StatusBadge({ status, notes, order }: { status: string, notes?: string, order?: any }) {
  const needsProcessing = order && (!order.agency_id || !order.customer_phone || !order.cod_amount);
  
  if (status === 'ACTIVE') {
    if (needsProcessing) {
      return <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border border-amber-200 bg-amber-50 text-amber-700">Cần xử lý</span>;
    }
    return <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border border-emerald-200 bg-emerald-50 text-emerald-700">Hiệu lực</span>;
  }
  if (status === 'NEEDS_PROCESSING') {
    return <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border border-amber-200 bg-amber-50 text-amber-700">Cần xử lý</span>;
  }
  return (
    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border border-red-200 bg-red-50 text-red-700">
      Đã hủy {notes?.includes('HỦY') ? `(${notes.replace('HỦY', '').trim()})` : ''}
    </span>
  );
}

function OrderFormModal({ order, onClose, onSave, users, currentUser }: any) {
  const [formData, setFormData] = useState({
    insurance_type: order?.insurance_type || 'TNDS_OTO',
    serial_number: order?.serial_number || '',
    vehicle_owner: order?.vehicle_owner || '',
    license_plate: order?.license_plate || '',
    issue_date: order?.issue_date || new Date().toISOString().split('T')[0],
    effective_date: order?.effective_date || new Date().toISOString().split('T')[0],
    tnds_fee: order?.tnds_fee || 0,
    nn_fee: order?.nn_fee || 0,
    total_fee: order?.total_fee || 0,
    provider: order?.provider || '',
    staff_id: order?.staff_id || (currentUser.role === 'STAFF' ? currentUser.id : ''),
    agency_id: order?.agency_id || (currentUser.role === 'AGENCY' ? currentUser.id : ''),
    customer_phone: order?.customer_phone || '',
    cod_amount: order?.cod_amount || 0,
    shipping_fee: order?.shipping_fee || 0,
    payment_status: order?.payment_status || 'UNPAID',
    status: order?.status || 'ACTIVE',
    notes: order?.notes || '',
  });

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    let newValue: any = value;
    
    if (['tnds_fee', 'nn_fee', 'cod_amount', 'shipping_fee'].includes(name)) {
      newValue = Number(value);
    }
    
    setFormData(prev => {
      const next = { ...prev, [name]: newValue };
      if (name === 'tnds_fee' || name === 'nn_fee') {
        next.total_fee = Number(next.tnds_fee) + Number(next.nn_fee);
      }
      return next;
    });
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-slate-200 sticky top-0 bg-white z-10">
          <h2 className="text-xl font-semibold text-slate-800">{order ? 'Sửa Đơn Bảo Hiểm' : 'Thêm Đơn Mới'}</h2>
          <button type="button" onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h3 className="font-medium text-slate-900 border-b pb-2">Thông tin chung</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Loại nghiệp vụ <span className="text-red-500">*</span></label>
                  <select required name="insurance_type" value={formData.insurance_type} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm">
                    <option value="TNDS_OTO">TNDS Ô tô</option>
                    <option value="VCX_OTO">Vật chất xe Ô tô</option>
                    <option value="TNDS_XEMAY">TNDS Xe máy</option>
                    <option value="Y_TE">Bảo hiểm Y tế</option>
                    <option value="ETC">Thẻ ETC</option>
                    <option value="KHAC">Khác</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Hãng (Provider)</label>
                  <input type="text" name="provider" value={formData.provider} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" placeholder="VD: VIỄN ĐÔNG" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Số Seri / Số Thẻ / GCN <span className="text-red-500">*</span></label>
                <input required type="text" name="serial_number" value={formData.serial_number} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Ngày cấp <span className="text-red-500">*</span></label>
                  <input required type="date" name="issue_date" value={formData.issue_date} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Ngày hiệu lực <span className="text-red-500">*</span></label>
                  <input required type="date" name="effective_date" value={formData.effective_date} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" />
                </div>
              </div>
              
              <h3 className="font-medium text-slate-900 border-b pb-2 mt-6">Thông tin khách hàng</h3>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Chủ xe / Tên KH <span className="text-red-500">*</span></label>
                <input required type="text" name="vehicle_owner" value={formData.vehicle_owner} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Biển số xe</label>
                  <input type="text" name="license_plate" value={formData.license_plate} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">SĐT Khách hàng</label>
                  <input type="text" name="customer_phone" value={formData.customer_phone} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="font-medium text-slate-900 border-b pb-2">Thông tin phí & Thanh toán</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Phí TNDS</label>
                  <input type="number" name="tnds_fee" value={formData.tnds_fee} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Phí LP NNTX</label>
                  <input type="number" name="nn_fee" value={formData.nn_fee} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Tổng phí</label>
                  <input type="number" readOnly value={formData.total_fee} className="w-full border border-slate-200 bg-slate-50 rounded-lg px-3 py-2 text-sm font-semibold text-slate-900" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Trạng thái thanh toán <span className="text-red-500">*</span></label>
                  <select name="payment_status" value={formData.payment_status} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm">
                    <option value="UNPAID">Chưa thanh toán</option>
                    <option value="PARTIAL">Thanh toán 1 phần</option>
                    <option value="PAID">Đã thanh toán</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Số tiền COD</label>
                  <input type="number" name="cod_amount" value={formData.cod_amount} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Phí Vận chuyển</label>
                  <input type="number" name="shipping_fee" value={formData.shipping_fee} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" />
                </div>
              </div>

              <h3 className="font-medium text-slate-900 border-b pb-2 mt-6">Phân công & Ghi chú</h3>
              {(currentUser.role === 'MASTER' || currentUser.role === 'ACCOUNTANT' || currentUser.role === 'STAFF') && (
                <div className="grid grid-cols-2 gap-4">
                  {(currentUser.role === 'MASTER' || currentUser.role === 'ACCOUNTANT') && (
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Nhân viên (Người cấp)</label>
                      <select name="staff_id" value={formData.staff_id} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm">
                        <option value="">Chọn nhân viên...</option>
                        {users.filter(u => u.role === 'STAFF').map(u => (
                          <option key={u.id} value={u.id}>{u.fullname}</option>
                        ))}
                      </select>
                    </div>
                  )}
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Đại lý</label>
                    <select name="agency_id" value={formData.agency_id} onChange={handleChange} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm">
                      <option value="">Không có</option>
                      {users.filter(u => u.role === 'AGENCY' && (currentUser.role === 'MASTER' || currentUser.role === 'ACCOUNTANT' || u.parent_id === currentUser.id)).map(u => (
                        <option key={u.id} value={u.id}>{u.fullname}</option>
                      ))}
                    </select>
                  </div>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Ghi chú / Mã Giao dịch</label>
                <textarea name="notes" value={formData.notes} onChange={handleChange} rows={2} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"></textarea>
              </div>
            </div>
          </div>
          
          <div className="mt-8 pt-6 border-t border-slate-200 flex justify-end gap-3 sticky bottom-0 bg-white">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50">
              Hủy bỏ
            </button>
            <button type="submit" className="px-6 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">
              {order ? 'Lưu thay đổi' : 'Tạo đơn mới'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
