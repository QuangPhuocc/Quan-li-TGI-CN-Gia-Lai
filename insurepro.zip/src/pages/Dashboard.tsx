import React, { useMemo, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { PieChart, Pie, Cell, Legend, Tooltip, ResponsiveContainer } from 'recharts';
import { Wallet, FileText, AlertCircle, TrendingUp, X } from 'lucide-react';
import { InsuranceOrder, User } from '../types';

const getDoanhThu = (o: InsuranceOrder) => {
  return Math.round((o.tnds_fee / 1.1) + o.nn_fee);
};

export default function Dashboard() {
  const { user } = useAuth();
  const { orders, users } = useData();
  const [selectedStaff, setSelectedStaff] = useState<User | null>(null);

  // Lọc dữ liệu theo Role
  const filteredOrders = useMemo(() => {
    if (user?.role === 'MASTER' || user?.role === 'ACCOUNTANT') return orders;
    if (user?.role === 'STAFF') {
      // Đơn của chính staff đó hoặc của agency thuộc staff đó
      const myAgencies = users.filter(u => u.parent_id === user.id).map(u => u.id);
      return orders.filter(o => o.staff_id === user.id || (o.agency_id && myAgencies.includes(o.agency_id)));
    }
    if (user?.role === 'AGENCY') {
      return orders.filter(o => o.agency_id === user.id);
    }
    return [];
  }, [orders, user, users]);

  const stats = useMemo(() => {
    const totalRev = filteredOrders.filter(o => o.status === 'ACTIVE').reduce((acc, curr) => acc + getDoanhThu(curr), 0);
    const unpaid = filteredOrders.filter(o => o.payment_status === 'UNPAID' && o.status === 'ACTIVE').reduce((acc, curr) => acc + curr.total_fee, 0);
    const cancelledCount = filteredOrders.filter(o => o.status === 'CANCELLED').length;
    const renewalCount = filteredOrders.filter(o => o.status === 'ACTIVE').length; // Mock

    return { totalRev, unpaid, cancelledCount, renewalCount };
  }, [filteredOrders]);

  // Chart by Provider (Hãng) instead of Insurance Type
  const chartData = useMemo(() => {
    const providerMap = new Map<string, number>();
    filteredOrders.forEach(o => {
      if (o.status === 'CANCELLED') return;
      const providerName = o.provider || 'Khác';
      const rev = getDoanhThu(o);
      providerMap.set(providerName, (providerMap.get(providerName) || 0) + rev);
    });

    return Array.from(providerMap.entries()).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [filteredOrders]);

  // Bảng theo dõi theo Nhân viên (Chỉ MASTER)
  const staffStats = useMemo(() => {
    if (user?.role !== 'MASTER') return [];
    const staffs = users.filter(u => u.role === 'STAFF');
    return staffs.map(staff => {
      const staffAgencies = users.filter(u => u.parent_id === staff.id).map(u => u.id);
      const sOrders = orders.filter(o => o.staff_id === staff.id || (o.agency_id && staffAgencies.includes(o.agency_id)));
      
      const sRev = sOrders.filter(o => o.status === 'ACTIVE').reduce((sum, o) => sum + getDoanhThu(o), 0);
      const collected = sOrders.filter(o => o.payment_status === 'PAID' && o.status === 'ACTIVE').reduce((sum, o) => sum + o.total_fee, 0);
      const sUnpaid = sOrders.filter(o => o.payment_status === 'UNPAID' && o.status === 'ACTIVE').reduce((sum, o) => sum + o.total_fee, 0);
      const sCancelList = sOrders.filter(o => o.status === 'CANCELLED');
      const sUnpaidList = sOrders.filter(o => o.payment_status === 'UNPAID' && o.status === 'ACTIVE');

      return { 
        staff,
        count: sOrders.length, 
        rev: sRev, 
        collected,
        unpaid: sUnpaid, 
        cancelledList: sCancelList,
        unpaidList: sUnpaidList,
        orders: sOrders
      };
    });
  }, [orders, users, user]);

  const formatCurrency = (val: number) => new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(val);

  return (
    <div className="space-y-6 relative">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-slate-800">Hiệu quả tổng quan</h1>
        <select className="border-slate-300 rounded-lg text-sm bg-white shadow-sm px-3 py-2 outline-none">
          <option>Tháng này</option>
          <option>Hôm nay</option>
          <option>Tùy chọn...</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Tổng doanh thu" value={formatCurrency(stats.totalRev)} icon={<Wallet className="text-blue-600" />} bg="bg-blue-50" />
        <StatCard title="Công nợ chưa thu" value={formatCurrency(stats.unpaid)} icon={<AlertCircle className="text-amber-600" />} bg="bg-amber-50" />
        <StatCard title="Số đơn hủy" value={stats.cancelledCount} icon={<FileText className="text-red-600" />} bg="bg-red-50" />
        <StatCard title="Đơn đến hạn tái tục" value={stats.renewalCount} icon={<TrendingUp className="text-emerald-600" />} bg="bg-emerald-50" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h2 className="text-lg font-medium text-slate-800 mb-4">Doanh thu theo Hãng</h2>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                >
                  {chartData.map((entry, index) => {
                    const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#6366f1'];
                    return <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />;
                  })}
                </Pie>
                <Tooltip formatter={(value: number) => formatCurrency(value)} />
                <Legend verticalAlign="bottom" height={36} iconType="circle" />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Master only: Staff performance */}
        {user?.role === 'MASTER' && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 overflow-hidden flex flex-col h-full max-h-[400px]">
            <h2 className="text-lg font-medium text-slate-800 mb-4">Hiệu suất Nhân viên</h2>
            <div className="flex-1 overflow-y-auto pr-2 -mr-2">
              <div className="space-y-4">
                {staffStats.map(s => (
                  <div 
                    key={s.staff.id} 
                    onClick={() => setSelectedStaff(s.staff)}
                    className="p-4 rounded-lg bg-slate-50 border border-slate-100 cursor-pointer hover:border-blue-300 hover:bg-blue-50 transition-colors"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-medium text-slate-800">{s.staff.fullname}</span>
                      <span className="text-xs font-semibold bg-blue-100 text-blue-700 px-2 py-0.5 rounded">{s.count} đơn</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500">Doanh thu:</span>
                      <span className="font-medium text-slate-900">{formatCurrency(s.rev)}</span>
                    </div>
                    <div className="flex justify-between text-sm mt-1">
                      <span className="text-slate-500">Công nợ:</span>
                      <span className="font-medium text-amber-600">{formatCurrency(s.unpaid)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Staff Detail Modal */}
      {selectedStaff && (
        <StaffDetailModal 
          staff={selectedStaff}
          stats={staffStats.find(s => s.staff.id === selectedStaff.id)!}
          onClose={() => setSelectedStaff(null)} 
        />
      )}
    </div>
  );
}

function StatCard({ title, value, icon, bg }: { title: string, value: string | number, icon: React.ReactNode, bg: string }) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 flex items-start gap-4">
      <div className={`p-3 rounded-lg ${bg}`}>
        {icon}
      </div>
      <div>
        <p className="text-sm font-medium text-slate-500 mb-1">{title}</p>
        <h3 className="text-2xl font-bold text-slate-900">{value}</h3>
      </div>
    </div>
  );
}

function StaffDetailModal({ staff, stats, onClose }: { staff: User, stats: any, onClose: () => void }) {
  const formatCurrency = (val: number) => new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(val);

  return (
    <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-slate-200 bg-white z-10">
          <div>
            <h2 className="text-xl font-semibold text-slate-800">Chi tiết nhân viên: {staff.fullname}</h2>
            <p className="text-sm text-slate-500 mt-1">
              Đã thu: <span className="font-medium text-emerald-600 mr-4">{formatCurrency(stats.collected)}</span>
              Chưa thu: <span className="font-medium text-amber-600">{formatCurrency(stats.unpaid)}</span>
            </p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-8 bg-slate-50">
          {/* Unpaid List */}
          <div>
            <h3 className="text-sm font-semibold text-amber-700 uppercase tracking-wider mb-3 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              Danh sách đơn chưa thanh toán ({stats.unpaidList.length})
            </h3>
            <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
              <OrderMiniTable orders={stats.unpaidList} />
            </div>
          </div>

          {/* Cancelled List */}
          <div>
            <h3 className="text-sm font-semibold text-red-700 uppercase tracking-wider mb-3 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-500"></span>
              Danh sách thẻ hủy ({stats.cancelledList.length})
            </h3>
            <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
              <OrderMiniTable orders={stats.cancelledList} />
            </div>
          </div>

          {/* All Orders List */}
          <div>
            <h3 className="text-sm font-semibold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-500"></span>
              Toàn bộ đơn bảo hiểm ({stats.orders.length})
            </h3>
            <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
              <OrderMiniTable orders={stats.orders} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function OrderMiniTable({ orders }: { orders: InsuranceOrder[] }) {
  if (orders.length === 0) {
    return <div className="p-4 text-center text-sm text-slate-500 bg-slate-50">Không có dữ liệu</div>;
  }
  return (
    <table className="w-full text-left border-collapse text-sm">
      <thead>
        <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
          <th className="px-4 py-3">Mã GCN</th>
          <th className="px-4 py-3">Khách hàng</th>
          <th className="px-4 py-3">Hãng</th>
          <th className="px-4 py-3 text-right">Tổng phí</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-slate-100">
        {orders.map(o => (
          <tr key={o.id} className="hover:bg-slate-50">
            <td className="px-4 py-3 font-medium text-blue-600">{o.serial_number || o.id}</td>
            <td className="px-4 py-3 text-slate-700">{o.vehicle_owner}</td>
            <td className="px-4 py-3 text-slate-600">{o.provider || '-'}</td>
            <td className="px-4 py-3 text-right font-medium text-slate-900">
              {new Intl.NumberFormat('vi-VN').format(o.total_fee)} ₫
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
