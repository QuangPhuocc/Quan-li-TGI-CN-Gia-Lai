import React, { createContext, useContext, useState } from 'react';
import { InsuranceOrder, User } from '../types';
import { mockOrders, mockUsers } from '../mock/data';

interface DataContextType {
  orders: InsuranceOrder[];
  users: User[];
  addOrder: (order: InsuranceOrder) => void;
  updateOrder: (id: string, updates: Partial<InsuranceOrder>) => void;
  addUser: (user: User) => void;
  updateUser: (id: string, updates: Partial<User>) => void;
  deleteUser: (id: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [orders, setOrders] = useState<InsuranceOrder[]>(mockOrders);
  const [users, setUsers] = useState<User[]>(mockUsers);

  const addOrder = (order: InsuranceOrder) => {
    setOrders(prev => [order, ...prev]);
  };

  const updateOrder = (id: string, updates: Partial<InsuranceOrder>) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, ...updates, updated_at: new Date().toISOString() } : o));
  };

  const addUser = (user: User) => {
    setUsers(prev => [...prev, user]);
  };

  const updateUser = (id: string, updates: Partial<User>) => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, ...updates } : u));
  };

  const deleteUser = (id: string) => {
    setUsers(prev => prev.filter(u => u.id !== id));
  };

  return (
    <DataContext.Provider value={{ orders, users, addOrder, updateOrder, addUser, updateUser, deleteUser }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
